import socket
import time

from dhcp.Packet import Packet

clientPort = 67
serverPort = 68
serverIP= [9, 9, 9, 9]

# open UDP socket
server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
server.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
server.bind(("", serverPort))
list_addr = []
ip_addr = [0, 0, 0, 0]



while True:
    data, client_addr = server.recvfrom(1024)
    print("Received message")
    list_data = list(data)

    list_info = Packet.data_handler(list_data)

    if list_info.count('packet_type') != 0:

        packet_type = list_info[list_info.index('packet_type')+1]

        if packet_type == 1: #discover
            print("This is a discover packet")
            count = 0
            request_ip = list_info[list_info.index('request_ip')+1]
            if list_addr.count(request_ip) == 0: #if we do not have this ip addr in the list, the client can use it
                list_addr.insert(len(list_addr), request_ip) #put in the list
                ip_addr = request_ip

            else:

                for i in range(10, 255):
                    if list_addr.count([127, 0, 0, i]) == 0:
                        list_addr.insert(len(list_addr), [127, 0, 0, i])
                        ip_addr = list_addr[len(list_addr) - 1]
                        break
                    else:
                        count += 1


            if count == 255:
                print("There is no free address in the subnet")
                break

            packet = Packet(2, list_info[list_info.index('ID') + 1], [0, 0, 0, 0], ip_addr, serverIP, list_info[list_info.index('client_mac_addr') + 1])
            domain_name = "MiryamAndMasuah"
            packet.offer([255, 255, 255, 0], domain_name, len(domain_name), [127, 0, 0, 2])

            server.sendto(packet.packet, ("255.255.255.255", clientPort))
            print("Offer has been sent")



        if packet_type == 3: #request
            print("This is a request packet")
            packet = Packet(2, list_info[list_info.index('ID') + 1], [0, 0, 0, 0], ip_addr, serverIP, list_info[list_info.index('client_mac_addr') + 1])
            domain_name = "MiryamAndMasuah"
            packet.ack ([255, 255, 255, 0], domain_name, len (domain_name), [127, 0, 0, 2])

            server.sendto(packet.packet, ("255.255.255.255", clientPort))
            print("ACK has been sent")
















