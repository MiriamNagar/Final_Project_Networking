
from random import randint
from uuid import getnode as get_mac
from scapy.layers.dhcp import *
from dhcp.Packet import Packet

clientPort = 67
serverPort = 68
client_ip = [0, 0, 0, 0]
domain_name = ""
domain_ip = [0, 0, 0, 0]

def id() -> bytes:
    ans = b''
    for i in range(4):
        t = randint(0, 255)
        ans += struct.pack('!B', t)
    return ans
########################################################################################################

# open UDP socket
client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
client.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1) #broadcast
client.bind(("", clientPort))





while True:

    ID = list(id())
    #discover
    packet = Packet(1, ID, client_ip, [0, 0, 0, 0], [0, 0, 0, 0], list(get_mac().to_bytes(6, "big")))
    packet.discover([127, 0, 0, 3], [1, 15, 6], 3)

    client.sendto(packet.packet, ("255.255.255.255", serverPort))
    print("Discover has been sent")

    data, server_addr = client.recvfrom(1024)

    print("Received message")
    list_data = list(data)

    list_info = Packet.data_handler(list_data)

    if list_info.count('packet_type') != 0:
        packet_type = list_info[list_info.index('packet_type') + 1]

        if packet_type == 2:
            print("This is an offer packet")

            if list_info[list_info.index('ID')+1] != ID:
                print("Not the right ID")
                break

            domain_name = list_info[list_info.index('domain_name')+1]
            domain_ip = list_info[list_info.index('domain_ip')+1]

            #request
            packet = Packet(1, ID, client_ip, [0, 0, 0, 0], [0, 0, 0, 0], list(get_mac().to_bytes(6, "big")))
            packet.request()

            client.sendto(packet.packet, ("255.255.255.255", serverPort))
            print("Request has been sent")
            client_ip = list_info[list_info.index('your_ip_addr') + 1]

            data, server_addr = client.recvfrom(1024)
            print("Received message")
            list_data = list(data)
            list_info = Packet.data_handler(list_data)
            packet_type = list_info[list_info.index('packet_type') + 1]

        if packet_type == 5:
            if list_info[list_info.index('ID')+1] != ID:
                print("Not the right ID")
                break
            print("got the ACK")
            print("My new IP addres is:")
            print(client_ip)
            break

        else:
            print("restart ip_addr, try again")
            client_ip = [0, 0, 0, 0]








