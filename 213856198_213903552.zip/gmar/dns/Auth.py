import socket
from random import randint

from dns.Packet import Packet

port =53
tld_ip = "127.0.0.7"
bufferSize = 1024

# Create a UDP socket

UDPServerSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

# Bind to address and ip

UDPServerSocket.bind((tld_ip, port))

print("Auth 'dns_example.com' up and listening")


short_name = "dns_example.com"
long_name = "www.msmn.dns_example.com"
ip_addr=[[127,0,0,8],[127,0,0,8],[127,0,0,8]]  #they are the same because we didnt want to make more servers...




while (True):
    bytesAddressPair = UDPServerSocket.recvfrom(bufferSize)

    message = bytesAddressPair[0]

    address = bytesAddressPair[1]

    DNSMsg = "Message from DNS:{}".format(message)
    DNSIP = "DNS IP Address:{}".format(address)

    print(DNSMsg)
    print(DNSIP)
    #handle the request

    print(list(message))
    data = Packet.data_handler(list(message))
    print(data)
    name_domain = ""
    for i in range(len(data[(data.index('qname')+1)])):
        name_domain += (data[(data.index('qname')+1)][i].to_bytes(1, "big")).decode()

    print(name_domain)

    id = data[data.index('id') + 1]

    if name_domain != short_name:
        print("Can't find addr")
        break
    rand=randint(0,2)
    ip_addr_final = ip_addr[rand]

    msgFromRoot = Packet(id, 33152, 1, 1,0, name_domain, 1, 1, 10, 4, ip_addr_final)

    bytesToSend = msgFromRoot.packet

    # Sending a reply to DNS with the auth ip

    UDPServerSocket.sendto(bytesToSend, address)
    print("Auth sent the final ip")