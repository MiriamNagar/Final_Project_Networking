import socket

from datetime import datetime
from time import time

from dns.Packet import Packet

port =53
dns_ip = "127.0.0.2"
root_ip = "127.0.0.3"


bufferSize = 1024

my_cache_addr = [["name"], ["value"], ["type"], ["ttl"], ["start_time"]]
my_cache_tld = [["name"], ["value"], ["type"], ["ttl"], ["start_time"]]




# Create a UDP server socket

UDPServerSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

# Bind to address and ip

UDPServerSocket.bind((dns_ip, port))

print("DNS server up and listening")

# Create a UDP client socket

UDPClientSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)




while (True):
    done = False  # if there is error it is true
    #recv request for ip addr from client
    fromClient = UDPServerSocket.recvfrom(bufferSize)

    client_message = fromClient[0]

    client_address = fromClient[1]

    clientMsg = "Message from Client:{}".format(client_message)
    clientIP = "Client IP Address:{}".format(client_address)

    print(clientMsg)
    print(clientIP)
    #handle the msg

    print(list(client_message))
    data = Packet.data_handler(list(client_message))
    print(data)
    name_domain = ""
    for i in range  (len(data[(data.index('qname')+1)])):
        name_domain += (data[(data.index('qname')+1)][i].to_bytes(1, "big")).decode()

    print(name_domain)
    id = data[data.index('id') + 1]

    if my_cache_addr[0].count(name_domain) > 0: #if we have the answer in the cache:


        if my_cache_addr[3][my_cache_addr[0].index(name_domain)] > time()-my_cache_addr[4][my_cache_addr[0].index(name_domain)]: #if the ttl bigger than now-start time(we can use tha ans)
            value = my_cache_addr[1][my_cache_addr[0].index(name_domain)]
            # Sending a reply to client

            msgFromDNS = Packet(id, 33152, 1, 1, 0, name_domain, 1, 1, 50, 4, value)

            bytesToSend = msgFromDNS.packet
            UDPServerSocket.sendto(bytesToSend, client_address)
        else: #we can't use the ans, we need to delete it and then:
            my_cache_addr[1].pop(my_cache_addr[0].index(name_domain))
            my_cache_addr[2].pop(my_cache_addr[0].index(name_domain))
            my_cache_addr[3].pop(my_cache_addr[0].index(name_domain))
            my_cache_addr[4].pop(my_cache_addr[0].index(name_domain))
            my_cache_addr[0].pop(my_cache_addr[0].index(name_domain))



    if my_cache_addr[0].count(name_domain) == 0: #we check again because maybe we needed to delete
        index_p = name_domain.index(".")  # find the endig
        ending = ""
        for i in range(index_p, len(name_domain)):
            ending += name_domain[i]


        if my_cache_tld[0].count(ending) > 0:  # if we have the tld ip in the cache:
            if my_cache_tld[3][my_cache_tld[0].index(ending)] > time() - my_cache_tld[4][my_cache_tld[0].index(ending)]:  # if the ttl bigger than now-start time(we can use tha ans)
                tld_ip = my_cache_tld[1][my_cache_tld[0].index(ending)]

            else:  # we can't use the ans, we need to delete it and then:
                my_cache_tld[1].pop(my_cache_tld[0].index(ending))
                my_cache_tld[2].pop(my_cache_tld[0].index(ending))
                my_cache_tld[3].pop(my_cache_tld[0].index(ending))
                my_cache_tld[4].pop(my_cache_tld[0].index(ending))
                my_cache_tld[0].pop(my_cache_tld[0].index(ending))

        if my_cache_tld[0].count(ending) == 0: #we check again because maybe we needed to delete

            #send to root requst for tld ip
            id = data[data.index('id') + 1]
            msgFromDNS = Packet(id, 1, 1, 0, 0, name_domain, 1, 1, 0, 0, 0)

            bytesToSend = msgFromDNS.packet

            rootAddress = (root_ip, port)

            UDPClientSocket.sendto(bytesToSend, rootAddress)

            #recv the answer from the root

            fromRoot = UDPClientSocket.recvfrom(bufferSize)

            root_message = fromRoot[0]

            root_address = fromRoot[1]

            RootMsg = "Message from Root:{}".format(root_message)
            RootIP = "Root IP Address:{}".format(root_address)

            print(RootMsg)
            if len(root_message) == len("Error can't find tld"):
                if root_message.decode() == "Error can't find tld":
                    print("error")
                    bytesToSend = "Error can't find addr".encode()
                    UDPServerSocket.sendto(bytesToSend, client_address)
                    done=True
            else:
                print(list(root_message))
                data = Packet.data_handler(list(root_message))
                print(data)

                #find tld ip addr

                len_tld_ip = data[data.index('answer_ip_len')+1]
                print(len_tld_ip)
                tld_ip = ""
                for i in range(len_tld_ip):
                    tld_ip += str(data[data.index('answer_ip')+1][i])
                    tld_ip += '.'

                tld_ip = tld_ip[0:len(tld_ip)-1]
                print(tld_ip)

                #add the tld_ip to the cache
                my_cache_tld[0].append(ending)
                my_cache_tld[1].append(tld_ip)
                my_cache_tld[2].append(data[data.index("qtype")+1])
                ttl = data[data.index("ttl") + 1][3] + data[data.index("ttl") + 1][2]*10 +data[data.index("ttl") + 1][1]*100+data[data.index("ttl") + 1][0]*1000
                my_cache_tld[3].append(ttl)
                my_cache_tld[4].append(time())



        # send to tld requst
        if done == False:
            msgFromDNS = Packet(id, 1, 1, 0, 0, name_domain, 1, 1, 0, 0, 0)

            bytesToSend = msgFromDNS.packet

            tldAddress = (tld_ip, port)

            UDPClientSocket.sendto(bytesToSend, tldAddress)

            # recv the answer from the TLD

            from_tld = UDPClientSocket.recvfrom(bufferSize)

            tld_message = from_tld[0]

            tld_address = from_tld[1]

            TLDMsg = "Message from TLD:{}".format(tld_message)
            TLDIP = "TLD IP Address:{}".format(tld_address)

            print(TLDMsg)
            if len(tld_message) == len("Error can't find addr"):
                if tld_message.decode() == "Error can't find addr":
                    print("error")
                    bytesToSend = "Error can't find addr".encode()
                    UDPServerSocket.sendto(bytesToSend, client_address)
            else:
                print(list(tld_message))
                data = Packet.data_handler(list(tld_message))
                print(data)


                len_auth_ip = data[data.index('answer_ip_len') + 1]
                print(len_auth_ip)
                auth_ip = ""

                for i in range(len_auth_ip):
                    auth_ip += str(data[data.index('answer_ip') + 1][i])
                    auth_ip += '.'

                auth_ip = auth_ip[0:len(auth_ip) - 1]

                print(auth_ip)


                # send to auth requst for final answer

                msgFromDNS = Packet(id, 1, 1, 0, 0, name_domain, 1, 1, 0, 0, 0)

                bytesToSend = msgFromDNS.packet

                authAddress = (auth_ip, port)

                UDPClientSocket.sendto(bytesToSend, authAddress)

                # recv the answer from the TLD

                from_auth = UDPClientSocket.recvfrom(bufferSize)

                auth_message = from_auth[0]

                auth_address = from_auth[1]

                authMsg = "Message from auth:{}".format(auth_message)
                authIP = "auth IP Address:{}".format(auth_address)

                print(authMsg)
                print(list(auth_message))
                data = Packet.data_handler(list(auth_message))
                print(data)

                len_ip = data[data.index('answer_ip_len') + 1]
                print(len_ip)
                final_ip_str = ""
                final_ip_arr =[]

                for i in range(len_ip):
                    final_ip_str += str(data[data.index('answer_ip') + 1][i])
                    final_ip_str += '.'
                    final_ip_arr.insert(i,data[data.index('answer_ip') + 1][i])

                final_ip_str = final_ip_str[0:len(final_ip_str) - 1]


                print(final_ip_str)
                print(final_ip_arr)


                # add the final ip to the cache
                my_cache_addr[0].append(name_domain)
                my_cache_addr[1].append(final_ip_arr)
                my_cache_addr[2].append(data[data.index("qtype") + 1])
                ttl = data[data.index("ttl") + 1][3] + data[data.index("ttl") + 1][2] * 10 + data[data.index("ttl") + 1][1] * 100 + data[data.index("ttl") + 1][0] * 1000
                my_cache_addr[3].append(ttl)
                my_cache_addr[4].append(time())


                # Sending a reply to client

                msgFromDNS = Packet(id, 33152, 1, 1, 0, name_domain, 1, 1, 50, 4, final_ip_arr)

                bytesToSend = msgFromDNS.packet
                UDPServerSocket.sendto(bytesToSend, client_address)

















