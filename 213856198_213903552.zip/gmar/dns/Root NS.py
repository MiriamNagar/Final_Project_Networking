import socket
from dns.Packet import Packet

port =53
root_ip = "127.0.0.3"
bufferSize = 1024

# Create a UDP socket

UDPServerSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

# Bind to address and ip

UDPServerSocket.bind((root_ip, port))

print("Root up and listening")

my_TLD_list = [".com", [127,0,0,4], ".org", [127,0,0,5], ".il", [127,0,0,6]]


while (True):
    bytesAddressPair = UDPServerSocket.recvfrom(bufferSize)

    message = bytesAddressPair[0]

    address = bytesAddressPair[1]

    DNSMsg = "Message from DNS:{}".format(message)
    DNSIP = "DNS IP Address:{}".format(address)

    print(DNSMsg)
    print(DNSIP)

    # handle the request

    print(list(message))
    data = Packet.data_handler(list(message))
    print(data)
    name_domain = ""
    for i in range(len(data[(data.index('qname')+1)])):
        name_domain += (data[(data.index('qname')+1)][i].to_bytes(1, "big")).decode()

    print(name_domain)
    index_p = name_domain.index(".")  # find the endig
    print(index_p)

    ending = ""
    for i in range(index_p, len(name_domain)):
        ending += name_domain[i]

    print(ending)


    if my_TLD_list.count(ending) == 0:
        print("Can't find tld")
        bytesToSend = "Error can't find tld".encode()
        # sending error
        UDPServerSocket.sendto(bytesToSend, address)
    else:
        ip_tld = my_TLD_list[my_TLD_list.index(ending)+1]
        id = data[data.index('id') + 1]
        msgFromRoot = Packet(id, 33152, 1,1,0,name_domain, 1, 1,50,4,ip_tld)
        bytesToSend = msgFromRoot.packet

    # Sending a reply to DNS with the tld ip

        UDPServerSocket.sendto(bytesToSend, address)
        print("root sent the tld ip")
