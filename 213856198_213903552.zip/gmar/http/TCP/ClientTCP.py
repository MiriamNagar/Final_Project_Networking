# import socket
from socket import *

SERVER_ADDRESS = ('localhost', 14000)
BUFFER = 1024
client_file = "received.txt"


def receive_file(file_name, clientconnection):
    f = open(file_name, 'wb')
    file_size = int(clientconnection.recv(BUFFER).decode())
    clientconnection.sendall("next".encode())
    offset = 0
    while offset < file_size:
        data = clientconnection.recv(BUFFER)
        f.write(data)
        offset += len(data)
    f.close()


# open client socket
clientSocket = socket(AF_INET, SOCK_STREAM)
# connecting to http server
clientSocket.connect(SERVER_ADDRESS)
sentence = input('Input file name:')
clientSocket.sendall(sentence.encode())
# receive answer
message = clientSocket.recv(BUFFER).decode()
if message == "sending...":
    receive_file(client_file, clientSocket)
else:
    print("error in receiving file")
clientSocket.close()
