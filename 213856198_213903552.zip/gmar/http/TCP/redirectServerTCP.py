from socket import *

SERVER_ADDRESS = ('localhost', 8888)
filenames = ["original.txt"]
BUFFER = 1024


def send_file(file_name, connection: socket):
    f = open(file_name, 'rb')
    data = f.read()
    file_size = len(data)
    connection.sendall(str(file_size).encode())
    connection.recv(BUFFER)
    offset = 0
    while offset < file_size:
        packet = data[offset:offset+BUFFER]
        connection.sendall(packet)
        offset += len(packet)
    f.close()


serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.bind(SERVER_ADDRESS)
serverSocket.listen(1)
print("The server is ready to receive client")
while True:
    # connectionSocket is connected to httpserver client
    connectionSocket, addressClient = serverSocket.accept()
    filename = connectionSocket.recv(BUFFER).decode()
    if filename in filenames:
        connectionSocket.send("sending...".encode())
        send_file(filename, connectionSocket)
    else:
        connectionSocket.send("error".encode())
    connectionSocket.close()
