import random
import time
from socket import *
from threading import Thread

host = "https://www.project.com"
userA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 " \
        "Safari/537.36 "
accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8"
acceptLanguage = "he-IL,he;q=0.9"
AcceptEncoding = "gzip, deflate"

SYN = "SYN"
ACK = "ACK"
NACK = "NACK"
SPACE = " "
GET = "GET"


class Client:
    def __init__(self):
        self.SERVER_ADDRESS = ("127.0.0.8", 20198)
        # self.FILENAME = "send.txt"
        self.BUFFER = 1024
        self.TIME_OUT = 15
        self.WINDOW_SIZE = 10
        self.FILE_NAME = "received_file.txt"
        self.ack_seq_num = 0
        self.sequence_number = 0
        self.packets_list = []
        self.clientSocket = None

    # Construct the HTTP request #
    def build_get_request(self, host, server, version, connection, upgradeI, userA, accept, secGPC, acceptLanguage,
                          acceptEncoding):
        request = "GET {} HTTP/{}\r\nHost: {}\r\n".format(host, version, server)
        request += "Connection: {}\r\n".format(connection)
        request += "Upgrade-Insecure-Requests: {}\r\n".format(upgradeI)
        request += "User-Agent: {}\r\n".format(userA)
        request += "Accept: {}\r\n".format(accept)
        request += "Sec-GPC: {}\r\n".format(secGPC)
        request += "Accept-Language: {}\r\n".format(acceptLanguage)
        request += "Accept-Encoding: {}\r\n".format(acceptEncoding)
        return request

    def get_response(self):
        try:
            rec_msg, serverAddr = self.clientSocket.recvfrom(self.BUFFER)
            return rec_msg.decode()
        except:# socket.timeout as e:
             return "FAILED"

    def send_buffer_window(self):
        print("sending buffer and window size...")
        buffer_window_message = "{} {}".format(self.WINDOW_SIZE, self.BUFFER)
        self.clientSocket.sendto(buffer_window_message.encode(), self.SERVER_ADDRESS)

    def handshake(self):
        self.clientSocket.sendto(SYN.encode(), self.SERVER_ADDRESS)
        print("sent connection request")
        response = self.get_response()
        if response == ACK:
            print("connection made, sending get request")
            request = self.build_get_request("/", host, "1.1", "keep-alive", "1", userA, accept, "1", acceptLanguage,
                                        AcceptEncoding)
            self.clientSocket.sendto(request.encode(), self.SERVER_ADDRESS)
            response = self.get_response()
            if response == ACK:
                return True
            elif response == NACK:
                return False
        else:
            return False

    def latency(self):
        randon_num = random.random()
        if randon_num < 0.5:
            print(randon_num)
            time.sleep(1)
        else:
            pass

    def receive_file(self):
        while True:
            try:
                data, serverAddress = self.clientSocket.recvfrom(self.BUFFER)
                print("receiving data")
                if data.decode() == "done":
                    print("break")
                    break
                self.ack_seq_num = int(data.split()[0].decode())
                print(self.ack_seq_num)
                start = data.find(SPACE.encode())
                data = data[start+1:]
                self.packets_list.insert(self.ack_seq_num, data)
                # self.latency()
                self.clientSocket.sendto(str(self.ack_seq_num).encode(), self.SERVER_ADDRESS)
                print("sending ack")
            except:
                print("Time-out. File transfer failed.")


    def write_file(self):
        with open(self.FILE_NAME, 'wb') as f:
            for i in self.packets_list:
                f.write(i)

    def run_client(self):
        self.clientSocket = socket(AF_INET, SOCK_DGRAM)
        #self.clientSocket.settimeout(self.TIME_OUT)
        connection = self.handshake()
        if not connection:
            print("connection failed")
        else:
            self.send_buffer_window()
            file_name = input('Input file name:')
            self.clientSocket.sendto(file_name.encode(), self.SERVER_ADDRESS)
            data, serverAddress = self.clientSocket.recvfrom(self.BUFFER)
            if data.decode() == NACK:
                print("file name doesn't exist in web")
            elif data.decode() == ACK:
                self.receive_file()
                self.write_file()
            print("closing socket")
            self.clientSocket.close()


#main
client = Client()
client.run_client()