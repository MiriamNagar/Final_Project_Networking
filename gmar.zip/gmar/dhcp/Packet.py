class Packet:

    def __init__(self, message_type, id,  client_ip_address, your_ip_address, server_ip_address, client_mac_address):

        self.packet = b''
        self.packet += message_type.to_bytes(1, "big")  # Message type: Boot Request (1), Boot replay(2)
        self.packet += b'\x01'  # Hardware type: Ethernet
        self.packet += b'\x06'  # Hardware address length: 6
        self.packet += b'\x00'  # Hops: 0
        for i in range(4):
            self.packet += id[i].to_bytes(1, "big") # ID
        self.packet += b'\x00\x00'  # Seconds elapsed: 0
        self.packet += b'\x00\x00'  # Bootp flags: 0x0000
        for i in range(4):
            self.packet += client_ip_address[i].to_bytes(1, "big")  # Client IP address
        for i in range(4):
            self.packet += your_ip_address[i].to_bytes(1, "big")  # Your (client) IP address
        for i in range(4):
            self.packet += server_ip_address[i].to_bytes(1, "big")  # Next server IP address
        self.packet += b'\x00\x00\x00\x00'  # Relay agent IP address: 0.0.0.0
        for i in range(6):
            self.packet += client_mac_address[i].to_bytes(1, "big")  # Client MAC address
        self.packet += b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'  # Client hardware address padding: '00000000000000000000'
        self.packet += b'\x00' * 67  # Server host name not given
        self.packet += b'\x00' * 125  # Boot file name not given
        self.packet += b'\x63\x82\x53\x63'  # Magic cookie: DHCP




    def discover(self,request_ip, list_prameters, len_list ):
        packet_type = 1
        self.packet += b'\x35\x01'  # Option: (t=53,l=1)
        self.packet += packet_type.to_bytes(1, "big")  # DHCP Message Type = Discover(1)
        self.packet += b'\x32\x04' #option(50) request IP address
        for i in range(4):
            self.packet += request_ip[i].to_bytes(1, "big")
        self.packet += b'\x37'  # Option: (t=55,l=len_list) Parameter Request List
        self.packet += len_list.to_bytes(1, "big")
        for i in range(len_list):
            self.packet += list_prameters[i].to_bytes(1, "big")
        self.packet += b'\xff'  # End Option



    def offer(self, subnet_mask, domain_name, domain_len_name, domain_ip):
        packet_type = 2
        self.packet += b'\x35\x01'  # Option: (t=53,l=1)
        self.packet += packet_type.to_bytes(1, "big")  # DHCP Message Type = Offer(2)
        self.packet += b'\x01\x04' #optin(1) subnet mask
        for i in range(4):
            self.packet += subnet_mask[i].to_bytes(1, "big")
        self.packet += b'\x0f' + domain_len_name.to_bytes(1, "big") + domain_name.encode() #option (15) domain name
        self.packet += b'\x06\x04' #optin (6) domain IP
        for i in range(4):
            self.packet += domain_ip[i].to_bytes(1, "big")
        self.packet += b'\xff'  # End Option





    def request(self):
        packet_type = 3
        self.packet += b'\x35\x01'  # Option: (t=53,l=1)
        self.packet += packet_type.to_bytes(1, "big")  # DHCP Message Type = Request(3)
        self.packet += b'\xff'  # End Option

    def ack(self, subnet_mask, domain_name, domain_len_name,  domain_ip ):
        packet_type = 5
        self.packet += b'\x35\x01'  # Option: (t=53,l=1)
        self.packet += packet_type.to_bytes(1, "big")  # DHCP Message Type = Ack(5)
        self.packet += b'\x01\x04'  # optin(1) subnet mask
        for i in range(4):
            self.packet += subnet_mask[i].to_bytes(1, "big")
        self.packet += b'\x0f' + domain_len_name.to_bytes(1, "big")  + domain_name.encode()  # option (15) domain name
        self.packet += b'\x06\x04'  # optin (6) domain IP
        for i in range(4):
            self.packet += domain_ip[i].to_bytes(1, "big")
        self.packet += b'\xff'  # End Option

    def data_handler(list_data):
        list_info = []

        list_info.insert(0, 'massege_type')
        list_info.insert(1, (list_data[0]))
        list_info.insert(2, 'hardware_type')
        list_info.insert(3, list_data[1])
        list_info.insert(4, 'ID')
        list_info.insert(5, list([list_data[4], list_data[5], list_data[6], list_data[7]]))
        list_info.insert(6, 'client_ip_addr')
        list_info.insert(7, list([list_data[12], list_data[13], list_data[14], list_data[15]]))
        list_info.insert(8, 'your_ip_addr')
        list_info.insert(9, list([list_data[16], list_data[17], list_data[18], list_data[19]]))
        list_info.insert(10, 'server_ip_addr')
        list_info.insert(11, list([list_data[20], list_data[21], list_data[22], list_data[23]]))
        list_info.insert(12, 'client_mac_addr')
        list_info.insert(13, list(
            [list_data[28], list_data[29], list_data[30], list_data[31], list_data[32], list_data[33]]))

        list_info.insert(14, 'packet_type')
        list_info.insert(15, list_data[242])

        if list_info[15] == 1:  # discover
            list_info.insert(16, 'request_ip')
            list_info.insert(17, list([list_data[245], list_data[246], list_data[247], list_data[248]]))
            list_info.insert(18, 'list_prameters')
            for i in range(list_data[250]):
                list_info.insert(19 + i, list_data[251 + i])

        if list_info[15] == 2 or list_info[15] == 5:  # offer+ack
            list_info.insert(16, 'subnet_mask')
            list_info.insert(17, list([list_data[245], list_data[246], list_data[247], list_data[248]]))
            list_info.insert(18, 'domain_name')
            list_info.insert(19, list(
                [list_data[251], list_data[252], list_data[253], list_data[254], list_data[255], list_data[256]]))
            list_info.insert(20, 'domain_ip')
            list_info.insert(21, list([list_data[-5], list_data[-4], list_data[-3], list_data[-2]]))

        return list_info


