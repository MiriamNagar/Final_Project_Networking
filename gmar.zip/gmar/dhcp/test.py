# from socket import *
# clientPort = 67
# serverPort = 68
#
# serverSocket = socket(AF_INET, SOCK_DGRAM)
#
# # Enable broadcasting mode
# serverSocket.setsockopt(serverSocket.SOL_SOCKET, serverSocket.SO_BROADCAST, 1)
# print("The DHCP is ready to receive...")
#
#
# discover, clientAddress = serverSocket.recvfrom(2048)
#
# while discover.decode() != "Discover":
#     discover, clientAddress = serverSocket.recvfrom(2048)
#
# print("i got dis")
# serverSocket.close()
#
#
#
#
#
#
#
#
#
# from socket import *
# clientPort = 67
# serverPort = 68
# # UDP
# clientSocket = socket(AF_INET, SOCK_DGRAM)
#
# clientSocket.setsockopt(clientSocket.SOL_SOCKET, clientSocket.SO_REUSEPORT, 1)
#
# # Enable broadcasting mode
# clientSocket.setsockopt(clientSocket.SOL_SOCKET, clientSocket.SO_BROADCAST, 1)
#
# discover = "Discover"
#
# clientSocket.sendto(discover.encode(), ("255.255.255.255", serverPort))
# print("dis was sent")
# clientSocket.close()

import scapy
from _socket import gethostbyname

from scapy.layers import dhcp
from scapy.layers.inet import IP, UDP, Ether
from scapy.layers.dhcp import *




# ethernet = Ether()
# ip = IP(src="0.0.0.0", dst="255.255.255.255")
# udp = UDP(sport=68, dport=67)
# bootps= BOOTP( ciaddr='0.0.0.0', flags=1)
# dhcps = DHCP(options=[("message-type", "discover"), "end"])
# packet = ethernet / ip / udp / bootps / dhcps





# def buildPacket(type):
#
#     packet = b''
#     packet += b'\x01'  # Message type: Boot Request (1)
#     packet += b'\x01'  # Hardware type: Ethernet
#     packet += b'\x06'  # Hardware address length: 6
#     packet += b'\x00'  # Hops: 0
#     packet += idd()#saction ID
#     packet += b'\x00\x00'  # Seconds elapsed: 0
#     packet += b'\x80\x00'  # Bootp flags: 0x8000 (Broadcast) + reserved flags
#     packet += b'\x00\x00\x00\x00'  # Client IP address: 0.0.0.0
#     packet += b'\x00\x00\x00\x00'  # Your (client) IP address: 0.0.0.0
#     packet += b'\x00\x00\x00\x00'  # Next server IP address: 0.0.0.0
#     packet += b'\x00\x00\x00\x00'  # Relay agent IP address: 0.0.0.0
#     packet += get_mac().to_bytes(6, "big") #Client MAC address
#     packet += b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'  # Client hardware address padding: 00000000000000000000
#     packet += b'\x00' * 67  # Server host name not given
#     packet += b'\x00' * 125  # Boot file name not given
#     packet += b'\x63\x82\x53\x63'  # Magic cookie: DHCP
#     packet += b'\x35\x01'  # Option: (t=53,l=1)
#     packet += type.to_bytes(1, "big") #DHCP Message Type = Discover(1), offer(2), request(3),Dcline(4), ack(5)
#     packet += b'\x3d\x06' + get_mac().to_bytes(6, "big") #Option: (t=61,l=6) Client identifier
#     packet += b'\x37\x03\x03\x01\x06'  # Option: (t=55,l=3) Parameter Request List
#     str = "hel.bn"
#     packet += b'\x0f\x06' + str.encode()
#     packet += b'\xff'  # End Option
#     return packet

import socket
import time
import scapy
from random import randint
from scapy.interfaces import NetworkInterface
from uuid import getnode as get_mac

from scapy.layers.inet import IP, UDP, Ether
from scapy.layers.dhcp import *
import codecs

#
# def get_mac_in_bytes():
#     mac = str(hex(get_mac()))
#     mac = mac[2:]
#     while len(mac) < 12:
#         mac = '0' + mac
#     macb = b''
#     for i in range(0, 12, 2):
#         m = int(mac[i:i + 2], 16)
#         macb += struct.pack('!B', m)
#     return macb
#
#
# print(get_mac_in_bytes())
# print(get_mac().to_bytes(6, "big"))
# type=1
# print(type.to_bytes(1, "big"))
# print(codecs.decode(get_mac().to_bytes(8, "little"), 'hex'))


import ast

print(gethostbyname("moodlearn.ariel.ac.il"))


# hex = b'\x10\x30'
#
#
# b = b"Lets grab a \x63\x82\x53\x63!"
# s = b.decode('ascii', "ignore")
# print(s)
# print(list(get_mac().to_bytes(6, "big")))
# s2= "example.com"
# print(s2.encode())
