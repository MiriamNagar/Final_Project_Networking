class Packet:

    def __init__(self, id, flags, question, answer,authority, qname, qtype, qclass,  ttl, rd_length, rd_data):
        self.packet = b''
        self.packet += id[0].to_bytes(1, "big")+id[1].to_bytes(1, "big")
        self.packet += flags.to_bytes(2, "big")
        self.packet += question.to_bytes(2, "big")
        self.packet += answer.to_bytes(2, "big")
        self.packet += authority.to_bytes(2, "big")
        self.packet += b'\x00\x00'
        self.packet += len(qname).to_bytes(1, "big")
        self.packet += qname.encode()
        self.packet += b'\x00'
        self.packet += qtype.to_bytes(2, "big")
        self.packet += qclass.to_bytes(2, "big")
        if answer > 0: #if there is an answer
            self.packet += b'\xc0' #a domain name pointer
            self.packet += b'\x0c'
            self.packet += qtype.to_bytes(2, "big")
            self.packet += qclass.to_bytes(2, "big")
            self.packet += ttl.to_bytes(4, "big")
            self.packet += rd_length.to_bytes(2, "big")
            for i in range(4):
                self.packet += rd_data[i].to_bytes(1, "big")
            self.packet += b'\x00'










    def data_handler(list_data):
        list_info = []

        list_info.insert(0, 'id')
        list_info.insert(1, ([list_data[0], list_data[1]]))
        list_info.insert(2, 'flags')
        list_info.insert(3, ([list_data[2], list_data[3]]))
        list_info.insert(4, 'question')
        list_info.insert(5, ([list_data[4], list_data[5]]))
        list_info.insert(6, 'answer')
        list_info.insert(7, ([list_data[6], list_data[7]]))
        list_info.insert(8, 'authority')
        list_info.insert(9, ([list_data[8], list_data[9]]))
        list_info.insert(10, 'len qname')
        list_info.insert(11, list_data[12])
        list_info.insert(12, 'qname')
        list_info.insert(13, [list_data[13]])
        for i in range(list_data[12] - 1):
            list_info[13].insert(i + 1, list_data[14 + i])
        len = list_data[12]
        list_info.insert(14, 'qclass')
        list_info.insert(15, ([list_data[13+len+1], list_data[13 +len +2]]))
        list_info.insert(16, 'qtype')
        list_info.insert(17, ([list_data[13+ len +3], list_data[13+ len + 4]]))
        if list_data[7] != 0:
            list_info.insert(18, 'answer_ip_len')
            list_info.insert(19, list_data[-6])
            list_info.insert(20, 'answer_ip')
            list_info.insert(21, ([list_data[-5], list_data[-4], list_data[-3], list_data[-2]]))
            list_info.insert(22, 'ttl')
            list_info.insert(23, ([list_data[-11], list_data[-10], list_data[-9], list_data[-8]]))


        return list_info


