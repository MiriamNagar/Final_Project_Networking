import socket
from dns.Packet import Packet

port =53
tld_ip = "127.0.0.4"
bufferSize = 1024

# Create a UDP socket

UDPServerSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

# Bind to address and ip

UDPServerSocket.bind((tld_ip, port))

print("TLD 'com' up and listening")


my_IP_addr_list = ["dns_example.com", [127,0,0,7], "dns1_exmple.com", [127,0,0,8], "dns2_exmple.com", [127,0,0,9]]




while (True):
    bytesAddressPair = UDPServerSocket.recvfrom(bufferSize)

    message = bytesAddressPair[0]

    address = bytesAddressPair[1]

    DNSMsg = "Message from DNS:{}".format(message)
    DNSIP = "DNS IP Address:{}".format(address)

    print(DNSMsg)
    print(DNSIP)
    #handle the request

    print(list(message))
    data = Packet.data_handler(list(message))
    print(data)
    name_domain = ""
    for i in range(len(data[(data.index('qname')+1)])):
        name_domain += (data[(data.index('qname')+1)][i].to_bytes(1, "big")).decode()

    print(name_domain)

    id = data[data.index('id') + 1]

    if my_IP_addr_list.count(name_domain) == 0:
        print("Can't find addr")
        bytesToSend = "Error can't find addr".encode()
        # sending error
        UDPServerSocket.sendto(bytesToSend, address)
    else:

        ip_auth = my_IP_addr_list[my_IP_addr_list.index(name_domain) + 1]

        msgFromRoot = Packet(id, 33152, 1, 1,0, name_domain, 1, 1, 50, 4, ip_auth)

        bytesToSend = msgFromRoot.packet

        # Sending a reply to DNS with the auth ip

        UDPServerSocket.sendto(bytesToSend, address)
        print("TLD sent the auth ip")
