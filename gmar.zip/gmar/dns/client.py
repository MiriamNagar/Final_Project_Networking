from uuid import getnode as get_mac
from dhcp.Packet import Packet

import socket
import struct
from random import randint

from dns.Packet import Packet as dnsPack

clientPort = 67
serverPort = 68
client_ip = [0, 0, 0, 0]
domain_name = ""
domain_ip = [0, 0, 0, 0]

keep_going = True

def id() -> bytes:
    ans = b''
    for i in range(4):
        t = randint(0, 255)
        ans += struct.pack('!B', t)
    return ans



port =53
bufferSize = 1024



address = input("please write the address of your website")

#our website address is- dns_example.com

msgFromClient = dnsPack(id(), 1, 1, 0,0, address, 1, 1,0,0, 0)

bytesToSend = msgFromClient.packet

dnsAddress = ("127.0.0.2", port)

# Create a UDP socket at client side

UDPClientSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

# Send to server using created UDP socket

UDPClientSocket.sendto(bytesToSend, dnsAddress)

msgFromServer = UDPClientSocket.recvfrom(bufferSize)

msg = msgFromServer[0]
#print(msg)

if len(msg) == len("Error can't find addr"):
    if msg.decode() == "Error can't find addr":
        print("Error can't find addr")
        UDPClientSocket.close()
        keep_going = False
else:
    #print(list(msg))
    data = dnsPack.data_handler(list(msg))
    #print(data)

    len_ip_app = data[data.index('answer_ip_len') + 1]
    #print(len_ip_app)
    app_ip_str = ""
    for i in range(len_ip_app):
        app_ip_str += str(data[data.index('answer_ip') + 1][i])
        app_ip_str += '.'

    app_ip_str = app_ip_str[0:len(app_ip_str) - 1]

    print("your website ip address is:")
    print(app_ip_str)

UDPClientSocket.close()

