import os
import random
from socket import *
from threading import Thread
import time

SYN = "SYN"
ACK = "ACK"
NACK = "NACK"
SPACE = " "
GET = "GET"

class HTTPServer:
    def __init__(self):
        self.REDIRECT_SERVER_ADDRESS = ('127.0.0.9', 30552)
        self.SERVER_ADDRESS = ("127.0.0.8", 20198)
        self.BUFFER = 1024
        self.TIME_OUT = 2
        self.MAX_WINDOW_SIZE = -1
        self.PACKET_SIZE = -1
        self.clients_list = []
        self.window_size = 4
        self.sequence_number = 0
        self.packets_transferred = 0
        self.retransmission_packets_list = {}
        self.client_Address = None
        self.serverSocket = None
        self.current_seq_ack = 0
        self.ack_list = [0]
        self.file_size = 0
        self.file_name = "send.txt"
        self.len_num_file_packets = 0
        self.ssthresh = 2
        self.START_WINDOW_SIZE = 2
        self.time_start = 0

    def packet_loss(self, probability):
        random_num = random.random()
        print(str(random_num))
        return random_num < probability

    def receive_file_from_redirect_server(self, file_name, connection):
        f = open(file_name, 'wb')
        file_size = int(connection.recv(self.BUFFER).decode())
        connection.send("next".encode())
        offset = 0
        while offset < file_size:
            data = connection.recv(self.BUFFER)
            f.write(data)
            offset += len(data)
        f.close()

    def TCP_connection_to_redirect(self, filename):
        httpclientSocket = socket(AF_INET, SOCK_STREAM)
        httpclientSocket.connect(self.REDIRECT_SERVER_ADDRESS)
        # sending file name we request
        httpclientSocket.sendall(filename.encode())
        message = httpclientSocket.recv(self.BUFFER).decode()
        if message == "sending...":
            self.receive_file_from_redirect_server(filename, httpclientSocket)
            print("received file from redirect server")
            httpclientSocket.close()
            return True
        elif message == "error":
            httpclientSocket.close()
            return False

    def rec_buffer_window(self):
        data, address = self.serverSocket.recvfrom(self.BUFFER)
        self.MAX_WINDOW_SIZE = int(data.split()[0].decode())
        self.PACKET_SIZE = int(data.split()[1].decode())
        self.PACKET_SIZE -= 3  # max 100 packets

    def handshake(self):
        try:
            message, clientAddress = self.serverSocket.recvfrom(self.BUFFER)
            self.client_Address = clientAddress
            message = message.decode()
            print("received message - handshake")
            if message == SYN:
                # add client to clients list and response with ack
                self.clients_list.append(clientAddress)
                self.serverSocket.sendto(ACK.encode(), self.client_Address)
                print("connection established\nclient address: " + str(clientAddress))
                return 1
            elif message[:3] == GET:
                print("received get request")
                if clientAddress in self.clients_list:
                    print("client in clients list")
                    self.serverSocket.sendto(ACK.encode(), self.client_Address)
                    return 1  # accept request
                else:
                    return 0
            else:
                return 0
        except:
            return -1

    def send_file_packets(self, filename):
        with open(filename.decode(), 'rb') as self.f:
            counter_sending = 0
            self.time_start = time.time()
            if self.sequence_number - self.current_seq_ack < self.window_size:
                for i in range(self.current_seq_ack, self.sequence_number):
                    drop_packet = self.packet_loss(-1)
                    if not drop_packet:
                        self.serverSocket.sendto(self.retransmission_packets_list[i], self.client_Address)
                        counter_sending += 1
            else:
                for i in range(self.current_seq_ack, self.current_seq_ack + self.window_size):
                    drop_packet = self.packet_loss(-1)
                    if not drop_packet:
                        self.serverSocket.sendto(self.retransmission_packets_list[i], self.client_Address)
                        counter_sending += 1
            for i in range(self.window_size - counter_sending):
                print("here again")
                self.f.seek(self.packets_transferred * self.PACKET_SIZE)
                # print(str(self.f.tell()))
                data = self.f.read(self.PACKET_SIZE)
                packet = str(self.sequence_number).encode() + SPACE.encode() + data
                self.retransmission_packets_list[self.sequence_number] = packet
                if self.sequence_number == self.len_num_file_packets:
                    break
                drop_packet = self.packet_loss(-1)
                if not drop_packet:
                    print("drop packet?: {}".format(drop_packet))
                    self.serverSocket.sendto(packet, self.client_Address)
                    print("sending packet num: " + str(self.sequence_number))
                    # print(str(self.f.tell()))
                    # print(data.decode())
                else:
                    print("     dropped packet number: {}".format(self.sequence_number))
                self.sequence_number += 1
                self.packets_transferred += 1

    def receive_acks(self):
        # try:
            # while self.current_seq_ack < self.sequence_number:

        time_end = time.time()
        self.serverSocket.settimeout(self.TIME_OUT)
        while ((time_end - self.time_start) < self.TIME_OUT) and (self.current_seq_ack < self.sequence_number):
            try:
                ack, clientAddress = self.serverSocket.recvfrom(self.BUFFER)
            except:
               break
            if len(ack.decode()) <= 2:
                ack_seq_num = int(ack.decode())
                print("received ack: "+str(ack_seq_num))
                self.ack_list[ack_seq_num] += 1
                if self.current_seq_ack == ack_seq_num:
                    # print(self.retransmission_packets_list)
                    self.retransmission_packets_list.pop(ack_seq_num)
                    if self.ack_list[self.current_seq_ack] == 3:
                        self.ack_list[self.current_seq_ack] = 0
                        self.ssthresh = int(self.window_size/2)
                        self.window_size = self.ssthresh + 3
                    self.current_seq_ack += 1
            time_end = time.time()
            print(str(self.current_seq_ack))
        if (time_end - self.time_start) >= self.TIME_OUT:
                self.ssthresh = int(self.window_size/2)
                self.window_size = self.START_WINDOW_SIZE
        else:
            self.congestion_control()


    def congestion_control(self):
        if self.window_size < self.MAX_WINDOW_SIZE:
            if self.window_size*2 < self.ssthresh:
                self.window_size *= 2
            else:
                self.window_size += 1

    def set_file_size(self, filename):
        self.file_size = os.path.getsize(filename)

    def set_num_packets_in_file(self):
        self.len_num_file_packets = self.file_size // self.PACKET_SIZE
        if self.file_size % self.PACKET_SIZE > 0:
            self.len_num_file_packets += 1

    def finish_sending(self):
        self.serverSocket.sendto("done".encode(), self.client_Address)
        print("finished sending")

    def run_server(self):

        self.serverSocket = socket(AF_INET, SOCK_DGRAM)
        self.serverSocket.bind(self.SERVER_ADDRESS)
        print("The server is ready to receive...")
        while True:
            connection = self.handshake()
            if connection == 0:
                self.serverSocket.sendto(NACK.encode(), self.client_Address)
                print("connection failed, did not receive Syn request, try again")
            elif connection == 1:
                connection = self.handshake()
                if connection == 0:
                    self.serverSocket.sendto(NACK.encode(), self.client_Address)
                    print("connection failed, not in clients list, try again")
                elif connection == 1:
                 #   self.serverSocket.settimeout(self.TIME_OUT)
                    self.rec_buffer_window()
                    print("max window size: " + str(self.MAX_WINDOW_SIZE))
                    print("packet size: " + str(self.PACKET_SIZE))
                    data, clientAddress = self.serverSocket.recvfrom(self.BUFFER)
                    self.file_name = data.decode()
                    self.set_file_size(self.file_name)
                    print("received file name:", self.file_name)
                    file_exist = self.TCP_connection_to_redirect(self.file_name)########
                    if not file_exist:
                        self.serverSocket.sendto(NACK.encode(), self.client_Address)
                    else:
                        self.serverSocket.sendto(ACK.encode(), self.client_Address)
                        self.set_num_packets_in_file()
                        self.ack_list = [0] * self.len_num_file_packets
                        print(str(self.len_num_file_packets))
                        print(str(self.file_size))
                        while True:
                            # self.send_file_packets(data)
                            thread1 = Thread(target=self.send_file_packets(data))
                            thread2 = Thread(target=self.receive_acks())
                            thread1.start()
                            thread2.start()
                            print("window size: " + str(self.window_size))
                            if self.current_seq_ack == self.len_num_file_packets:
                                self.finish_sending()
                                break
                        self.packets_transferred = 0
                        self.sequence_number = 0
                        self.window_size = 2
                        self.client_Address = None
                        self.serverSocket = None
                        self.current_seq_ack = 0
                        self.ack_list = [0]
                        self.len_num_file_packets = 0
                        self.ssthresh = 2
                        self.START_WINDOW_SIZE = 2



# main
server = HTTPServer()
server.run_server()
