# import socket
from socket import *

REDIRECT_SERVER_ADDRESS = ('localhost', 8888)
SERVER_ADDRESS = ('localhost', 14000)
BUFFER = 1024
FILE = "fromRedirect.txt"

def receive_file(file_name, connection):
    f = open(file_name, 'wb')
    file_size = int(connection.recv(BUFFER).decode())
    connection.send("next".encode())
    offset = 0
    while offset < file_size:
        data = connection.recv(BUFFER)
        f.write(data)
        offset += len(data)
    f.close()


def send_file(file_name, connection: socket):
    f = open(file_name, 'rb')
    data = f.read()
    file_size = len(data)
    connection.sendall(str(file_size).encode())
    connection.recv(BUFFER)
    offset = 0
    while offset < file_size:
        packet = data[offset:offset+BUFFER]
        connection.sendall(packet)
        offset += len(packet)
    f.close()


# main #
# server socket that will connect to client
serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.bind(SERVER_ADDRESS)
serverSocket.listen(1)
print("The server is ready to receive client")
while True:
    # connectionSocket is connected to client
    connectionSocket, addressClient = serverSocket.accept()
    file_name = connectionSocket.recv(BUFFER).decode()

    httpclientSocket = socket(AF_INET, SOCK_STREAM)
    httpclientSocket.connect(REDIRECT_SERVER_ADDRESS)
    # sending file name we request
    httpclientSocket.sendall("original.txt".encode())
    message = httpclientSocket.recv(BUFFER).decode()

    if message == "sending...":
        receive_file(FILE, httpclientSocket)
        connectionSocket.sendall("sending...".encode())
        send_file(FILE, connectionSocket)
        httpclientSocket.close()
    elif message == "error":
        print("error occurred")
        connectionSocket.sendall("NACK".encode())
        httpclientSocket.close()

    connectionSocket.close()
